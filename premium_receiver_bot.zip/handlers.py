import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import JOIN_CHANNEL, WITHDRAWAL_CHANNEL_ID, ADMIN_USER_IDS
import db

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = (
        f"Hello, {user.first_name}!\n\n"
        "Welcome to the Premium Account Receiver Bot.\n"
        "You must join the required channel to use full features.\n"
        "Use /balance to see your balance and /withdraw to request a withdrawal."
    )
    join_btn = InlineKeyboardMarkup([[InlineKeyboardButton(text='Join Channel', url=JOIN_CHANNEL)]])
    await update.message.reply_text(text, reply_markup=join_btn)

async def balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    bal = db.get_balance(user_id)
    await update.message.reply_text(f'Your balance: {bal} TRX')

async def withdraw_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    bal = db.get_balance(user_id)
    if bal <= 0:
        await update.message.reply_text('You have no balance to withdraw.')
        return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text('Usage: /withdraw <amount> <trx_wallet_address>')
        return
    try:
        amount = float(args[0])
    except:
        await update.message.reply_text('Invalid amount.')
        return
    wallet = args[1]
    if amount > bal:
        await update.message.reply_text('Insufficient balance.')
        return
    # Record withdrawal in DB and notify admin channel
    wid = db.record_withdrawal(user_id, amount, wallet, status='requested')
    # decrement balance
    db.remove_balance(user_id, amount)
    msg = f'🔔 New withdrawal request\nID: {wid}\nUser: {user_id}\nAmount: {amount}\nWallet: {wallet}'
    # send to admin/withdrawal channel via bot (context.bot)
    await context.bot.send_message(chat_id=WITHDRAWAL_CHANNEL_ID, text=msg)
    await update.message.reply_text('Withdrawal requested. Admin will review it soon.')

# Admin-only command pattern
async def add_balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_USER_IDS:
        await update.message.reply_text('Unauthorized.')
        return
    if len(context.args) < 2:
        await update.message.reply_text('Usage: /addbalance <user_id> <amount>')
        return
    try:
        target = int(context.args[0])
        amount = float(context.args[1])
    except:
        await update.message.reply_text('Invalid args.')
        return
    newbal = db.add_balance(target, amount)
    await update.message.reply_text(f'New balance for {target}: {newbal}')

async def withdrawals_by_date_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_USER_IDS:
        await update.message.reply_text('Unauthorized.')
        return
    if len(context.args) < 1:
        await update.message.reply_text('Usage: /withdrawals <YYYY-MM-DD>')
        return
    date_str = context.args[0]
    rows = db.list_withdrawals_by_date(date_str)
    if not rows:
        await update.message.reply_text('No withdrawals found on that date.')
        return
    text = 'Withdrawals:\n' + '\n'.join([str(r) for r in rows])
    await update.message.reply_text(text)
