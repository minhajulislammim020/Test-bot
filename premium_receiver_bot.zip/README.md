# Premium Account Receiver Bot (Python)

## What this project contains
- `bot.py` - main entrypoint using python-telegram-bot (async).
- `handlers.py` - command & message handlers split out for clarity.
- `db.py` - lightweight Redis + SQLite helpers for storing users, balances, pending confirmations, wallets.
- `admin.py` - admin helper commands (add/remove balance, view withdrawals, filter by date).
- `config.py` - configuration; edit for your environment.
- `requirements.txt` - pip requirements.

## Quick start (development)

1. Create a virtual environment and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. Edit `config.py` to set `REDIS_URL` and `ADMIN_USER_IDS`.
3. Run the bot:
   ```bash
   python bot.py
   ```

## Deployment notes
- For 24/7 hosting use services like Railway, Render, Heroku (paid/limited), or a small VPS.
- Use a systemd service or a process manager (supervisor) to keep the bot running.
- Keep bot token secret. Put sensitive values in environment variables and load them in `config.py`.

## Features implemented in code
- Join-channel check (users must join a channel before using bot features)
- Withdraw request flow (user requests withdrawal; an admin channel receives the request)
- Redis-backed balances, pending confirmations, and simple TRC20 wallet storage (placeholder)
- Admin commands for adding/removing balance and viewing withdrawals
- Basic error handling and logging
