import logging
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import config
import handlers

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def on_startup(app):
    logger.info('Bot starting...')

async def on_shutdown(app):
    logger.info('Bot shutting down...')

def main():
    app = ApplicationBuilder().token(config.BOT_TOKEN).build()

    # Register commands
    app.add_handler(CommandHandler('start', handlers.start))
    app.add_handler(CommandHandler('balance', handlers.balance_cmd))
    app.add_handler(CommandHandler('withdraw', handlers.withdraw_cmd))
    app.add_handler(CommandHandler('addbalance', handlers.add_balance_cmd))
    app.add_handler(CommandHandler('withdrawals', handlers.withdrawals_by_date_cmd))

    # Run long polling
    app.run_polling(stop_signals=None)

if __name__ == '__main__':
    main()
