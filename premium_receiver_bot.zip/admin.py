# Admin helper utilities (can be expanded)
from telegram import Update
from telegram.ext import ContextTypes
import db
from config import ADMIN_USER_IDS

async def is_admin(update: Update):
    return update.effective_user.id in ADMIN_USER_IDS
