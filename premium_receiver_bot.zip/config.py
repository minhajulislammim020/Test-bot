# Configuration file for Premium Account Receiver Bot
# NOTE: You provided the bot token; keep it secret in real deployments.
BOT_TOKEN = "8229716306:AAGFhmvEnz1Pxx2u6cEyFKA9y40H2NH72VA"
JOIN_CHANNEL = "https://t.me/testchannelwo"  # channel users must join
WITHDRAWAL_CHANNEL_ID = 3155713250  # channel/chat ID for withdrawal requests
ADMIN_USER_IDS = []  # add Telegram user IDs (integers) for admins
REDIS_URL = "redis://localhost:6379/0"  # change when deploying
DATABASE_FILE = "data.sqlite3"  # fallback local DB
