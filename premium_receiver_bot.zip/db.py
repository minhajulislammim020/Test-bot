import sqlite3
import redis
import json
from typing import Optional

from config import REDIS_URL, DATABASE_FILE

# Simple Redis client
r = redis.from_url(REDIS_URL, decode_responses=True)

# SQLite fallback for durable storage of essential records (withdrawals archive)
conn = sqlite3.connect(DATABASE_FILE, check_same_thread=False)
cur = conn.cursor()
cur.execute('''
CREATE TABLE IF NOT EXISTS withdrawals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    amount REAL,
    wallet TEXT,
    status TEXT,
    created_at TEXT
)
''')
conn.commit()

# -- Redis helpers -----------------------------------------------------------------
def get_balance(user_id: int) -> float:
    v = r.hget('balances', str(user_id))
    return float(v) if v is not None else 0.0

def set_balance(user_id: int, amount: float):
    r.hset('balances', str(user_id), float(amount))

def add_balance(user_id: int, delta: float):
    cur = get_balance(user_id) + delta
    set_balance(user_id, cur)
    return cur

def remove_balance(user_id: int, delta: float):
    cur = get_balance(user_id) - delta
    if cur < 0:
        cur = 0.0
    set_balance(user_id, cur)
    return cur

# Pending confirmations (e.g. phone number confirmations)
def add_pending(user_id: int, country: str, data: dict):
    key = f'pending:{country}'
    r.hset(key, str(user_id), json.dumps(data))

def list_pending(country: Optional[str]=None):
    if country:
        key = f'pending:{country}'
        return {k: json.loads(v) for k,v in r.hgetall(key).items()}
    else:
        out = {}
        for k in r.scan_iter(match='pending:*'):
            out[k] = {kk: json.loads(vv) for kk,vv in r.hgetall(k).items()}
        return out

# Withdrawals archival (SQLite) - keep a record for auditing
def record_withdrawal(user_id: int, amount: float, wallet: str, status='requested', created_at=None):
    cur = conn.cursor()
    cur.execute('INSERT INTO withdrawals (user_id, amount, wallet, status, created_at) VALUES (?, ?, ?, ?, datetime("now"))',
                (user_id, amount, wallet, status))
    conn.commit()
    return cur.lastrowid

def list_withdrawals_by_date(date_str: str):
    cur = conn.cursor()
    cur.execute('SELECT id, user_id, amount, wallet, status, created_at FROM withdrawals WHERE date(created_at)=?', (date_str,))
    return cur.fetchall()
